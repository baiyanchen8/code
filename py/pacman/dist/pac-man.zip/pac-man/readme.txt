# this is version 1 of pacman (ghost cather)
up:     ↑
down:   ↓   
left:   ←
right:  →
speedup(need 100  score):a
