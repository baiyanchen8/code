# this is method package to pac-man(ghost capture) game 
# last edit time 2023/5/17
# from editor chen po yen 

# import method 
from  . import Filemanage
from  . import keyboard
from  . import Button
from  . import creature
from  . import img_path
# from method import *
__all__ = ["keyboard","Filemanage","Button","creature","img_path"]
